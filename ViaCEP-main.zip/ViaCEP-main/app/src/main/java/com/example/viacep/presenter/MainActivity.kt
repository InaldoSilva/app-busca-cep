package com.example.viacep.presenter

import androidx.appcompat.app.AppCompatActivity
import com.example.viacep.R
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : AppCompatActivity(R.layout.activity_main)