package com.example.viacep.util

object Constants {

    const val REQUEST_KEY = "REQUEST_KEY"
    const val ADDRESS_BUNDLE_KEY = "ADDRESS_BUNDLE_KEY"

}